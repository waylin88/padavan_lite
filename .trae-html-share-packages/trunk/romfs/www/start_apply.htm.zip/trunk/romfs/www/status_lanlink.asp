<% lanlink(); %>
